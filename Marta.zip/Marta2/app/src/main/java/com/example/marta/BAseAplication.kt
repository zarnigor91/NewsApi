package com.example.marta

import dagger.android.AndroidInjector
import dagger.android.support.DaggerApplication

//class BAseAplication :DaggerApplication(){
//    override fun onCreate() {
//        super.onCreate()
//    }
//    override fun applicationInjector(): AndroidInjector<out DaggerApplication> {
//        val component: ApplicationComponent =
//            DaggerApplicationComponent.builder().application(this).build()
//        component.inject(this)
//
//        return component
//    }
//
//}