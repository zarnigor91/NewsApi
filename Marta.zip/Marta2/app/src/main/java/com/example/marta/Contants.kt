package com.example.marta

object Contants {
    val HAS_ACCOUNT: String = "HAS ACCOUNT"
}