package com.example.marta.network

import com.example.marta.model.LoginRequest
import com.example.marta.model.ModelUser
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST


const val BASE_URL="https://auth.marta.uz/"
interface IApiClient{

    @POST("oauth/token")
    suspend fun sigIn(@Body createLogin: LoginRequest): Response<ModelUser>

}