package com.example.marta

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import com.example.marta.model.LoginRequest
import com.example.marta.network.PostApi
import com.example.marta.utils.PreferencesUtil
import javax.inject.Inject
import com.example.marta.vm.loginViewModel
import kotlinx.android.synthetic.main.login_fragment.*

class LoginFragment :Fragment(R.layout.login_fragment){
    @Inject
    lateinit var api: PostApi
    @Inject
    lateinit var preferencesUtil: PreferencesUtil


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        injectDependency(this)
        loadData()
        bt_naxt_login.setOnClickListener {
            loginViewModel().getToken(LoginRequest(et_email.text.toString(), et_teach.text.toString(), et_password.text.toString()))
        }
    }

    private fun injectDependency(fragment:LoginFragment) {
        (activity?.application as App).getApiComponent().inject(fragment)
    }

    private fun loadData(){

        loginViewModel().init(api, preferencesUtil)

        loginViewModel().tokenLiveData.observe(viewLifecycleOwner, postObserver)

    }

    private val postObserver = Observer<String> {
        preferencesUtil.setToken(it)//Token yozildi
    }
}