package com.example.marta.network


import com.example.marta.model.LoginRequest
import com.example.marta.model.ModelUser
import retrofit2.Response
import retrofit2.http.Body

import retrofit2.http.POST


interface PostApi {

    @POST("oauth/token")
    suspend fun getPosts(@Body createLogin: LoginRequest): Response<ModelUser>


}